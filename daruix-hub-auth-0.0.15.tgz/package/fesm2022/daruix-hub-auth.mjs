import * as i0 from '@angular/core';
import { InjectionToken, inject, signal, computed, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';

const HUB_ACCESS_TOKEN_KEY = new InjectionToken('HUB_ACCESS_TOKEN_KEY', {
    providedIn: 'root',
    factory: () => 'daruix_hub_access_token',
});
const HUB_REFRESH_TOKEN_KEY = new InjectionToken('HUB_REFRESH_TOKEN_KEY', {
    providedIn: 'root',
    factory: () => 'daruix_hub_refresh_token',
});
const HUB_USER_KEY = new InjectionToken('HUB_USER_KEY', {
    providedIn: 'root',
    factory: () => 'daruix_hub_user',
});
const HUB_SESSION_KEY = new InjectionToken('HUB_SESSION_KEY', {
    providedIn: 'root',
    factory: () => 'daruix_hub_session',
});

class HubSessionService {
    accessTokenKey = inject(HUB_ACCESS_TOKEN_KEY);
    refreshTokenKey = inject(HUB_REFRESH_TOKEN_KEY);
    userKey = inject(HUB_USER_KEY);
    sessionKey = inject(HUB_SESSION_KEY);
    usuarioSignal = signal(this.loadUserFromStorage(), ...(ngDevMode ? [{ debugName: "usuarioSignal" }] : /* istanbul ignore next */ []));
    accessTokenSignal = signal(localStorage.getItem(this.accessTokenKey), ...(ngDevMode ? [{ debugName: "accessTokenSignal" }] : /* istanbul ignore next */ []));
    refreshTokenSignal = signal(localStorage.getItem(this.refreshTokenKey), ...(ngDevMode ? [{ debugName: "refreshTokenSignal" }] : /* istanbul ignore next */ []));
    sessaoSignal = signal(this.loadSessionFromStorage(), ...(ngDevMode ? [{ debugName: "sessaoSignal" }] : /* istanbul ignore next */ []));
    usuario = this.usuarioSignal.asReadonly();
    accessToken = this.accessTokenSignal.asReadonly();
    refreshToken = this.refreshTokenSignal.asReadonly();
    sessao = this.sessaoSignal.asReadonly();
    isSessionExpired = computed(() => {
        const sessao = this.sessao();
        if (!sessao?.expira_em) {
            return false;
        }
        return new Date(sessao.expira_em).getTime() <= Date.now();
    }, ...(ngDevMode ? [{ debugName: "isSessionExpired" }] : /* istanbul ignore next */ []));
    isLoggedIn = computed(() => !!this.accessToken() && !!this.usuario() && !this.isSessionExpired(), ...(ngDevMode ? [{ debugName: "isLoggedIn" }] : /* istanbul ignore next */ []));
    userName = computed(() => this.usuario()?.nome ?? this.usuario()?.username ?? '', ...(ngDevMode ? [{ debugName: "userName" }] : /* istanbul ignore next */ []));
    userPermissions = computed(() => this.usuario()?.permissoes ?? [], ...(ngDevMode ? [{ debugName: "userPermissions" }] : /* istanbul ignore next */ []));
    userModules = computed(() => this.usuario()?.modulos ?? [], ...(ngDevMode ? [{ debugName: "userModules" }] : /* istanbul ignore next */ []));
    hasPermission(permission) {
        return this.userPermissions().includes(permission);
    }
    hasModule(moduleSlug) {
        return this.userModules().some((modulo) => modulo.slug === moduleSlug);
    }
    setSession(params) {
        localStorage.setItem(this.userKey, JSON.stringify(params.usuario));
        localStorage.setItem(this.accessTokenKey, params.accessToken);
        localStorage.setItem(this.refreshTokenKey, params.refreshToken);
        localStorage.setItem(this.sessionKey, JSON.stringify(params.sessao));
        this.usuarioSignal.set(params.usuario);
        this.accessTokenSignal.set(params.accessToken);
        this.refreshTokenSignal.set(params.refreshToken);
        this.sessaoSignal.set(params.sessao);
    }
    setLoginResponse(response) {
        this.setSession({
            usuario: response.usuario,
            accessToken: response.access_token,
            refreshToken: response.refresh_token,
            sessao: response.sessao,
        });
    }
    setRefreshResponse(response) {
        localStorage.setItem(this.accessTokenKey, response.access_token);
        localStorage.setItem(this.refreshTokenKey, response.refresh_token);
        localStorage.setItem(this.sessionKey, JSON.stringify(response.sessao));
        this.accessTokenSignal.set(response.access_token);
        this.refreshTokenSignal.set(response.refresh_token);
        this.sessaoSignal.set(response.sessao);
    }
    setUsuario(usuario) {
        localStorage.setItem(this.userKey, JSON.stringify(usuario));
        this.usuarioSignal.set(usuario);
    }
    setAccessToken(accessToken) {
        localStorage.setItem(this.accessTokenKey, accessToken);
        this.accessTokenSignal.set(accessToken);
    }
    /**
     * Atualiza uma funcionalidade favoritada em qualquer
     * nível da árvore de módulos.
     *
     * A atualização cria novas referências e atualiza
     * usuarioSignal + localStorage através do setUsuario().
     */
    updateModuleFavorite(slug, favorito) {
        const usuario = this.usuario();
        if (!usuario) {
            return;
        }
        const modulos = this.updateFavoriteRecursively(usuario.modulos ?? [], slug, favorito);
        this.setUsuario({
            ...usuario,
            modulos,
        });
    }
    clearSession() {
        localStorage.removeItem(this.userKey);
        localStorage.removeItem(this.accessTokenKey);
        localStorage.removeItem(this.refreshTokenKey);
        localStorage.removeItem(this.sessionKey);
        this.usuarioSignal.set(null);
        this.accessTokenSignal.set(null);
        this.refreshTokenSignal.set(null);
        this.sessaoSignal.set(null);
    }
    reloadFromStorage() {
        this.usuarioSignal.set(this.loadUserFromStorage());
        this.accessTokenSignal.set(localStorage.getItem(this.accessTokenKey));
        this.refreshTokenSignal.set(localStorage.getItem(this.refreshTokenKey));
        this.sessaoSignal.set(this.loadSessionFromStorage());
        if (this.isSessionExpired()) {
            this.clearSession();
        }
    }
    updateFavoriteRecursively(items, slug, favorito) {
        return items.map((item) => ({
            ...item,
            favorito: item.slug === slug ? favorito : item.favorito,
            children: item.children?.length
                ? this.updateFavoriteRecursively(item.children, slug, favorito)
                : item.children,
        }));
    }
    loadUserFromStorage() {
        const usuario = localStorage.getItem(this.userKey);
        if (!usuario) {
            return null;
        }
        try {
            return JSON.parse(usuario);
        }
        catch {
            localStorage.removeItem(this.userKey);
            return null;
        }
    }
    loadSessionFromStorage() {
        const sessao = localStorage.getItem(this.sessionKey);
        if (!sessao) {
            return null;
        }
        try {
            return JSON.parse(sessao);
        }
        catch {
            localStorage.removeItem(this.sessionKey);
            return null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubSessionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubSessionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubSessionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class HubNavigationService {
    router = inject(Router);
    navigateRoute(route, item) {
        if (!route?.trim()) {
            return;
        }
        const resolvedRoute = this.resolveRoute(route, item);
        const cleanRoute = resolvedRoute
            .trim()
            .replace(/^\/hub\/?/, '')
            .replace(/^\/+|\/+$/g, '');
        if (!cleanRoute) {
            return;
        }
        void this.router.navigate(['/hub', ...cleanRoute.split('/')], {
            state: {
                moduleColor: item?.cor_icone,
                moduleIcone: item?.icone,
            },
        });
    }
    resolveRoute(route, item) {
        if (!item?.children?.length) {
            return route;
        }
        for (const child of item.children) {
            if (child.children?.length) {
                const target = child.children.find((nested) => nested.rota === route);
                if (target) {
                    return `${child.rota}/${target.rota}`;
                }
            }
            if (child.rota === route) {
                return item.modulo_slug ? `${item.modulo_slug}/${route}` : route;
            }
        }
        return route;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubNavigationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubNavigationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubNavigationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

let redirectingToLogin = false;
const hubAuthInterceptor = (req, next) => {
    const accessTokenKey = inject(HUB_ACCESS_TOKEN_KEY);
    const refreshTokenKey = inject(HUB_REFRESH_TOKEN_KEY);
    const userKey = inject(HUB_USER_KEY);
    const token = localStorage.getItem(accessTokenKey);
    const request = shouldAttachAccessToken(req) && token
        ? req.clone({
            setHeaders: {
                Authorization: `Bearer ${token}`,
            },
        })
        : req;
    return next(request).pipe(catchError((error) => {
        if (shouldLogoutUser(error, req.url)) {
            clearAuthentication({
                accessTokenKey,
                refreshTokenKey,
                userKey,
            });
            redirectToLogin();
        }
        return throwError(() => error);
    }));
};
function shouldAttachAccessToken(request) {
    const pathname = getPathname(request.url);
    return !isLoginEndpoint(pathname) && !isRefreshEndpoint(pathname);
}
function shouldLogoutUser(error, requestUrl) {
    if (!(error instanceof HttpErrorResponse)) {
        return false;
    }
    if (error.status !== 401) {
        return false;
    }
    const pathname = getPathname(requestUrl);
    /*
     * Um login com credenciais incorretas também pode retornar 401.
     * Nesse caso, apenas mostramos o erro no formulário.
     */
    if (isLoginEndpoint(pathname)) {
        return false;
    }
    return true;
}
function clearAuthentication(keys) {
    localStorage.removeItem(keys.accessTokenKey);
    localStorage.removeItem(keys.refreshTokenKey);
    localStorage.removeItem(keys.userKey);
    sessionStorage.removeItem(keys.accessTokenKey);
    sessionStorage.removeItem(keys.refreshTokenKey);
    sessionStorage.removeItem(keys.userKey);
}
function redirectToLogin() {
    if (redirectingToLogin) {
        return;
    }
    redirectingToLogin = true;
    /*
     * O replace recarrega o Shell e limpa também o estado
     * mantido em memória pelo SignalStore.
     */
    window.location.replace('/login');
}
function isLoginEndpoint(pathname) {
    return pathname.endsWith('/api/auth/login') || pathname.endsWith('/api/auth/login/');
}
function isRefreshEndpoint(pathname) {
    return pathname.endsWith('/api/auth/refresh') || pathname.endsWith('/api/auth/refresh/');
}
function getPathname(url) {
    try {
        return new URL(url, window.location.origin).pathname;
    }
    catch {
        return url.split('?')[0];
    }
}

const hubAuthGuard = () => {
    const session = inject(HubSessionService);
    const router = inject(Router);
    session.reloadFromStorage();
    if (session.isLoggedIn()) {
        return true;
    }
    return router.createUrlTree(['/login']);
};

const hubPermissionGuard = (route) => {
    const session = inject(HubSessionService);
    const router = inject(Router);
    session.reloadFromStorage();
    const requiredPermission = route.data?.['permission'];
    if (!requiredPermission) {
        return true;
    }
    if (session.hasPermission(requiredPermission)) {
        return true;
    }
    return router.createUrlTree(['/unauthorized']);
};

/**
 * Generated bundle index. Do not edit.
 */

export { HUB_ACCESS_TOKEN_KEY, HUB_REFRESH_TOKEN_KEY, HUB_SESSION_KEY, HUB_USER_KEY, HubNavigationService, HubSessionService, hubAuthGuard, hubAuthInterceptor, hubPermissionGuard };
//# sourceMappingURL=daruix-hub-auth.mjs.map
