import * as i0 from '@angular/core';
import { InjectionToken, inject, signal, computed, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpBackend, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError, tap, finalize, shareReplay, catchError, EMPTY, switchMap } from 'rxjs';
import { DOCUMENT } from '@angular/common';

const HUB_ACCESS_TOKEN_KEY = new InjectionToken('HUB_ACCESS_TOKEN_KEY', {
    providedIn: 'root',
    factory: () => 'daruix_hub_access_token',
});
const HUB_REFRESH_TOKEN_KEY = new InjectionToken('HUB_REFRESH_TOKEN_KEY', {
    providedIn: 'root',
    factory: () => 'daruix_hub_refresh_token',
});
const HUB_USER_KEY = new InjectionToken('HUB_USER_KEY', {
    providedIn: 'root',
    factory: () => 'daruix_hub_user',
});
const HUB_SESSION_KEY = new InjectionToken('HUB_SESSION_KEY', {
    providedIn: 'root',
    factory: () => 'daruix_hub_session',
});

class HubSessionService {
    accessTokenKey = inject(HUB_ACCESS_TOKEN_KEY);
    refreshTokenKey = inject(HUB_REFRESH_TOKEN_KEY);
    userKey = inject(HUB_USER_KEY);
    sessionKey = inject(HUB_SESSION_KEY);
    usuarioSignal = signal(this.loadUserFromStorage(), ...(ngDevMode ? [{ debugName: "usuarioSignal" }] : /* istanbul ignore next */ []));
    accessTokenSignal = signal(localStorage.getItem(this.accessTokenKey), ...(ngDevMode ? [{ debugName: "accessTokenSignal" }] : /* istanbul ignore next */ []));
    refreshTokenSignal = signal(localStorage.getItem(this.refreshTokenKey), ...(ngDevMode ? [{ debugName: "refreshTokenSignal" }] : /* istanbul ignore next */ []));
    sessaoSignal = signal(this.loadSessionFromStorage(), ...(ngDevMode ? [{ debugName: "sessaoSignal" }] : /* istanbul ignore next */ []));
    usuario = this.usuarioSignal.asReadonly();
    accessToken = this.accessTokenSignal.asReadonly();
    refreshToken = this.refreshTokenSignal.asReadonly();
    sessao = this.sessaoSignal.asReadonly();
    isSessionExpired = computed(() => {
        const sessao = this.sessao();
        if (!sessao?.expira_em) {
            return false;
        }
        return new Date(sessao.expira_em).getTime() <= Date.now();
    }, ...(ngDevMode ? [{ debugName: "isSessionExpired" }] : /* istanbul ignore next */ []));
    isLoggedIn = computed(() => !!this.accessToken() && !!this.usuario() && !this.isSessionExpired(), ...(ngDevMode ? [{ debugName: "isLoggedIn" }] : /* istanbul ignore next */ []));
    userName = computed(() => this.usuario()?.nome ?? this.usuario()?.username ?? '', ...(ngDevMode ? [{ debugName: "userName" }] : /* istanbul ignore next */ []));
    userPermissions = computed(() => this.usuario()?.permissoes ?? [], ...(ngDevMode ? [{ debugName: "userPermissions" }] : /* istanbul ignore next */ []));
    userModules = computed(() => this.usuario()?.modulos ?? [], ...(ngDevMode ? [{ debugName: "userModules" }] : /* istanbul ignore next */ []));
    hasPermission(permission) {
        return this.userPermissions().includes(permission);
    }
    hasModule(moduleSlug) {
        return this.userModules().some((modulo) => modulo.slug === moduleSlug);
    }
    setSession(params) {
        localStorage.setItem(this.userKey, JSON.stringify(params.usuario));
        localStorage.setItem(this.accessTokenKey, params.accessToken);
        localStorage.setItem(this.refreshTokenKey, params.refreshToken);
        localStorage.setItem(this.sessionKey, JSON.stringify(params.sessao));
        this.usuarioSignal.set(params.usuario);
        this.accessTokenSignal.set(params.accessToken);
        this.refreshTokenSignal.set(params.refreshToken);
        this.sessaoSignal.set(params.sessao);
    }
    setLoginResponse(response) {
        this.setSession({
            usuario: response.usuario,
            accessToken: response.access_token,
            refreshToken: response.refresh_token,
            sessao: response.sessao,
        });
    }
    setRefreshResponse(response) {
        localStorage.setItem(this.accessTokenKey, response.access_token);
        localStorage.setItem(this.refreshTokenKey, response.refresh_token);
        localStorage.setItem(this.sessionKey, JSON.stringify(response.sessao));
        this.accessTokenSignal.set(response.access_token);
        this.refreshTokenSignal.set(response.refresh_token);
        this.sessaoSignal.set(response.sessao);
    }
    setUsuario(usuario) {
        localStorage.setItem(this.userKey, JSON.stringify(usuario));
        this.usuarioSignal.set(usuario);
    }
    setAccessToken(accessToken) {
        localStorage.setItem(this.accessTokenKey, accessToken);
        this.accessTokenSignal.set(accessToken);
    }
    /**
     * Atualiza uma funcionalidade favoritada em qualquer
     * nível da árvore de módulos.
     *
     * A atualização cria novas referências e atualiza
     * usuarioSignal + localStorage através do setUsuario().
     */
    updateModuleFavorite(slug, favorito) {
        const usuario = this.usuario();
        if (!usuario) {
            return;
        }
        const modulos = this.updateFavoriteRecursively(usuario.modulos ?? [], slug, favorito);
        this.setUsuario({
            ...usuario,
            modulos,
        });
    }
    clearSession() {
        localStorage.removeItem(this.userKey);
        localStorage.removeItem(this.accessTokenKey);
        localStorage.removeItem(this.refreshTokenKey);
        localStorage.removeItem(this.sessionKey);
        this.usuarioSignal.set(null);
        this.accessTokenSignal.set(null);
        this.refreshTokenSignal.set(null);
        this.sessaoSignal.set(null);
    }
    reloadFromStorage() {
        this.usuarioSignal.set(this.loadUserFromStorage());
        this.accessTokenSignal.set(localStorage.getItem(this.accessTokenKey));
        this.refreshTokenSignal.set(localStorage.getItem(this.refreshTokenKey));
        this.sessaoSignal.set(this.loadSessionFromStorage());
        if (this.isSessionExpired()) {
            this.clearSession();
        }
    }
    updateFavoriteRecursively(items, slug, favorito) {
        return items.map((item) => ({
            ...item,
            favorito: item.slug === slug ? favorito : item.favorito,
            children: item.children?.length
                ? this.updateFavoriteRecursively(item.children, slug, favorito)
                : item.children,
        }));
    }
    loadUserFromStorage() {
        const usuario = localStorage.getItem(this.userKey);
        if (!usuario) {
            return null;
        }
        try {
            return JSON.parse(usuario);
        }
        catch {
            localStorage.removeItem(this.userKey);
            return null;
        }
    }
    loadSessionFromStorage() {
        const sessao = localStorage.getItem(this.sessionKey);
        if (!sessao) {
            return null;
        }
        try {
            return JSON.parse(sessao);
        }
        catch {
            localStorage.removeItem(this.sessionKey);
            return null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubSessionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubSessionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubSessionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class HubNavigationService {
    router = inject(Router);
    navigateRoute(route, item) {
        if (!route?.trim()) {
            return;
        }
        const resolvedRoute = this.resolveRoute(route, item);
        const cleanRoute = resolvedRoute
            .trim()
            .replace(/^\/hub\/?/, '')
            .replace(/^\/+|\/+$/g, '');
        if (!cleanRoute) {
            return;
        }
        void this.router.navigate(['/hub', ...cleanRoute.split('/')], {
            state: {
                moduleColor: item?.cor_icone,
                moduleIcone: item?.icone,
            },
        });
    }
    resolveRoute(route, item) {
        if (!item?.children?.length) {
            return route;
        }
        for (const child of item.children) {
            if (child.children?.length) {
                const target = child.children.find((nested) => nested.rota === route);
                if (target) {
                    return `${child.rota}/${target.rota}`;
                }
            }
            if (child.rota === route) {
                return item.modulo_slug ? `${item.modulo_slug}/${route}` : route;
            }
        }
        return route;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubNavigationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubNavigationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubNavigationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/**
 * Base URL da API do Daruix Hub.
 *
 * O Shell deve sobrescrever este token com environment.apiUrl.
 * O valor padrão atende o deploy onde a API é publicada em /api.
 */
const HUB_AUTH_API_URL = new InjectionToken('HUB_AUTH_API_URL', {
    providedIn: 'root',
    factory: () => '/api',
});

class HubAuthRefreshService {
    backend = inject(HttpBackend);
    session = inject(HubSessionService);
    apiUrl = inject(HUB_AUTH_API_URL);
    /**
     * Cliente sem interceptors.
     *
     * O refresh precisa ignorar o próprio hubAuthInterceptor para evitar
     * recursão quando o access token já está expirado.
     */
    rawHttp = new HttpClient(this.backend);
    /**
     * Compartilha um único refresh entre todas as requisições concorrentes.
     * Cinco chamadas que perceberem o JWT expirado ao mesmo tempo geram
     * somente um POST /auth/refresh/.
     */
    refreshInFlight$ = null;
    refreshAccessToken() {
        if (this.refreshInFlight$) {
            return this.refreshInFlight$;
        }
        const refreshToken = this.session.refreshToken();
        if (!refreshToken) {
            return throwError(() => new Error('Refresh token não disponível.'));
        }
        const request$ = this.rawHttp
            .post(this.authUrl('refresh/'), {
            refresh_token: refreshToken,
        })
            .pipe(tap((response) => this.session.setRefreshResponse(response)), finalize(() => {
            this.refreshInFlight$ = null;
        }), shareReplay({
            bufferSize: 1,
            refCount: false,
        }));
        this.refreshInFlight$ = request$;
        return request$;
    }
    authUrl(path) {
        const base = this.apiUrl.replace(/\/+$/, '');
        return `${base}/auth/${path}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubAuthRefreshService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubAuthRefreshService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubAuthRefreshService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/**
 * Intervalo máximo entre heartbeats enquanto existe atividade humana.
 *
 * O timer local verifica a cada 30s, mas uma chamada HTTP só ocorre quando:
 * - existe sessão ativa;
 * - houve mouse/teclado/scroll/toque desde o último heartbeat;
 * - passaram pelo menos 5 minutos desde o último heartbeat.
 */
const HEARTBEAT_INTERVAL_MS = 5 * 60 * 1000;
const HEARTBEAT_CHECK_INTERVAL_MS = 30 * 1000;
class HubUserActivityService {
    document = inject(DOCUMENT);
    http = inject(HttpClient);
    session = inject(HubSessionService);
    apiUrl = inject(HUB_AUTH_API_URL);
    started = false;
    heartbeatInFlight = false;
    activityPending = false;
    lastHumanActivityAt = 0;
    lastHeartbeatAt = Date.now();
    timerId = null;
    markActivityListener = () => this.markActivity();
    visibilityListener = () => {
        if (this.document.visibilityState === 'visible') {
            this.markActivity();
        }
    };
    start() {
        if (this.started) {
            return;
        }
        this.started = true;
        this.document.addEventListener('pointerdown', this.markActivityListener, {
            passive: true,
        });
        this.document.addEventListener('keydown', this.markActivityListener);
        this.document.addEventListener('wheel', this.markActivityListener, {
            passive: true,
        });
        this.document.addEventListener('touchstart', this.markActivityListener, {
            passive: true,
        });
        this.document.addEventListener('visibilitychange', this.visibilityListener);
        this.timerId = window.setInterval(() => this.flushActivityIfNeeded(), HEARTBEAT_CHECK_INTERVAL_MS);
    }
    markActivity() {
        this.lastHumanActivityAt = Date.now();
        this.activityPending = true;
    }
    ngOnDestroy() {
        if (!this.started) {
            return;
        }
        this.document.removeEventListener('pointerdown', this.markActivityListener);
        this.document.removeEventListener('keydown', this.markActivityListener);
        this.document.removeEventListener('wheel', this.markActivityListener);
        this.document.removeEventListener('touchstart', this.markActivityListener);
        this.document.removeEventListener('visibilitychange', this.visibilityListener);
        if (this.timerId !== null) {
            window.clearInterval(this.timerId);
            this.timerId = null;
        }
        this.started = false;
    }
    flushActivityIfNeeded() {
        if (!this.activityPending ||
            this.heartbeatInFlight ||
            !this.session.isLoggedIn()) {
            return;
        }
        const now = Date.now();
        if (now - this.lastHeartbeatAt < HEARTBEAT_INTERVAL_MS) {
            return;
        }
        /**
         * Não cria endpoint novo no BFF: /auth/me/ já é autenticado e a
         * SessionJWTAuthentication atualiza last_activity_at em toda chamada.
         *
         * O hubAuthInterceptor também atua nesta chamada. Se o access token
         * estiver perto de expirar, ele será renovado antes do /me/.
         */
        const activitySnapshot = this.lastHumanActivityAt;
        this.heartbeatInFlight = true;
        this.http
            .get(this.authUrl('me/'))
            .pipe(catchError(() => EMPTY), finalize(() => {
            this.heartbeatInFlight = false;
        }))
            .subscribe(() => {
            this.lastHeartbeatAt = Date.now();
            // Se houve nova interação enquanto a requisição estava em voo,
            // mantém activityPending=true para o próximo ciclo.
            this.activityPending = this.lastHumanActivityAt > activitySnapshot;
        });
    }
    authUrl(path) {
        const base = this.apiUrl.replace(/\/+$/, '');
        return `${base}/auth/${path}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubUserActivityService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubUserActivityService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.17", ngImport: i0, type: HubUserActivityService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/**
 * Renova de forma preventiva quando falta até 90s para o access expirar.
 * Isso evita a corrida de o token vencer entre o início e o fim da request.
 */
const REFRESH_SKEW_SECONDS = 90;
let redirectingToLogin = false;
const hubAuthInterceptor = (req, next) => {
    const session = inject(HubSessionService);
    const refreshService = inject(HubAuthRefreshService);
    if (!shouldAttachAccessToken(req)) {
        return next(req);
    }
    const accessToken = session.accessToken();
    if (!accessToken) {
        return next(req).pipe(catchError((error) => {
            if (isUnauthorized(error)) {
                endLocalSession(session);
            }
            return throwError(() => error);
        }));
    }
    if (isJwtNearExpiry(accessToken, REFRESH_SKEW_SECONDS)) {
        return refreshService.refreshAccessToken().pipe(switchMap(() => {
            const refreshedToken = session.accessToken();
            if (!refreshedToken) {
                endLocalSession(session);
                return throwError(() => new Error('Access token não disponível após refresh.'));
            }
            return next(withAccessToken(req, refreshedToken));
        }), catchError((error) => {
            endLocalSession(session);
            return throwError(() => error);
        }));
    }
    return next(withAccessToken(req, accessToken)).pipe(catchError((error) => {
        if (!isUnauthorized(error)) {
            return throwError(() => error);
        }
        /**
         * Fallback para 401: mesmo que o relógio do browser esteja diferente,
         * ou o token tenha sido invalidado entre as verificações, tenta um único
         * refresh e repete a requisição original.
         */
        return refreshService.refreshAccessToken().pipe(switchMap(() => {
            const refreshedToken = session.accessToken();
            if (!refreshedToken) {
                endLocalSession(session);
                return throwError(() => new Error('Access token não disponível após refresh.'));
            }
            return next(withAccessToken(req, refreshedToken));
        }), catchError((refreshError) => {
            endLocalSession(session);
            return throwError(() => refreshError);
        }));
    }));
};
function withAccessToken(request, token) {
    return request.clone({
        setHeaders: {
            Authorization: `Bearer ${token}`,
        },
    });
}
function shouldAttachAccessToken(request) {
    const pathname = getPathname(request.url);
    return !isLoginEndpoint(pathname) && !isRefreshEndpoint(pathname);
}
function isUnauthorized(error) {
    return error instanceof HttpErrorResponse && error.status === 401;
}
function endLocalSession(session) {
    session.clearSession();
    redirectToLogin();
}
function redirectToLogin() {
    if (redirectingToLogin) {
        return;
    }
    redirectingToLogin = true;
    window.location.replace('/login');
}
function isLoginEndpoint(pathname) {
    return pathname.endsWith('/auth/login') || pathname.endsWith('/auth/login/');
}
function isRefreshEndpoint(pathname) {
    return pathname.endsWith('/auth/refresh') || pathname.endsWith('/auth/refresh/');
}
function getPathname(url) {
    try {
        return new URL(url, window.location.origin).pathname;
    }
    catch {
        return url.split('?')[0];
    }
}
function isJwtNearExpiry(token, skewSeconds) {
    const expiresAt = readJwtExpiration(token);
    if (expiresAt === null) {
        return false;
    }
    return expiresAt * 1000 <= Date.now() + skewSeconds * 1000;
}
function readJwtExpiration(token) {
    const parts = token.split('.');
    if (parts.length !== 3) {
        return null;
    }
    try {
        const normalized = parts[1]
            .replace(/-/g, '+')
            .replace(/_/g, '/')
            .padEnd(Math.ceil(parts[1].length / 4) * 4, '=');
        const payload = JSON.parse(atob(normalized));
        return typeof payload.exp === 'number' ? payload.exp : null;
    }
    catch {
        return null;
    }
}

const hubAuthGuard = () => {
    const session = inject(HubSessionService);
    const router = inject(Router);
    session.reloadFromStorage();
    if (session.isLoggedIn()) {
        return true;
    }
    return router.createUrlTree(['/login']);
};

const hubPermissionGuard = (route) => {
    const session = inject(HubSessionService);
    const router = inject(Router);
    session.reloadFromStorage();
    const requiredPermission = route.data?.['permission'];
    if (!requiredPermission) {
        return true;
    }
    if (session.hasPermission(requiredPermission)) {
        return true;
    }
    return router.createUrlTree(['/unauthorized']);
};

/**
 * Generated bundle index. Do not edit.
 */

export { HUB_ACCESS_TOKEN_KEY, HUB_AUTH_API_URL, HUB_REFRESH_TOKEN_KEY, HUB_SESSION_KEY, HUB_USER_KEY, HubAuthRefreshService, HubNavigationService, HubSessionService, HubUserActivityService, hubAuthGuard, hubAuthInterceptor, hubPermissionGuard };
//# sourceMappingURL=daruix-hub-auth.mjs.map
