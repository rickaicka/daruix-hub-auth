import * as _angular_core from '@angular/core';
import { InjectionToken } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { CanActivateFn } from '@angular/router';

interface HubRemoteModule {
    remote_name: string;
    remote_entry: string;
    exposed_module: string;
}
interface HubModulo {
    slug: string;
    nome: string;
    rota: string;
    icone: string;
    permissao: string;
    cor_icone: string;
    desktop_enabled: boolean;
    mobile_enabled: boolean;
    mfe_enabled: boolean;
    legacy_enabled: boolean;
    favorito: boolean;
    favoritavel: boolean;
    remote: HubRemoteModule | null;
    children: HubModulo[];
}
interface HubUser {
    id_usuario: number;
    username: string;
    nome: string;
    email: string;
    tipo_usuario: string;
    grupo: string;
    permissoes: string[];
    modulos: HubModulo[];
    origem: string;
    ativo: boolean;
    is_staff: boolean;
    is_superuser: boolean;
}
interface HubSessionInfo {
    id: string;
    expira_em: string;
    inatividade_minutos: number;
}
interface HubAuthState {
    usuario: HubUser | null;
    accessToken: string | null;
    refreshToken: string | null;
    sessao: HubSessionInfo | null;
}
interface HubLoginResponse {
    access_token: string;
    refresh_token: string;
    token_type: 'bearer';
    usuario: HubUser;
    sessao: HubSessionInfo;
}
interface HubRefreshResponse {
    access_token: string;
    refresh_token: string;
    token_type: 'bearer';
    sessao: HubSessionInfo;
}

declare class HubSessionService {
    private readonly accessTokenKey;
    private readonly refreshTokenKey;
    private readonly userKey;
    private readonly sessionKey;
    private readonly usuarioSignal;
    private readonly accessTokenSignal;
    private readonly refreshTokenSignal;
    private readonly sessaoSignal;
    readonly usuario: _angular_core.Signal<HubUser | null>;
    readonly accessToken: _angular_core.Signal<string | null>;
    readonly refreshToken: _angular_core.Signal<string | null>;
    readonly sessao: _angular_core.Signal<HubSessionInfo | null>;
    readonly isSessionExpired: _angular_core.Signal<boolean>;
    readonly isLoggedIn: _angular_core.Signal<boolean>;
    readonly userName: _angular_core.Signal<string>;
    readonly userPermissions: _angular_core.Signal<string[]>;
    readonly userModules: _angular_core.Signal<HubModulo[]>;
    hasPermission(permission: string): boolean;
    hasModule(moduleSlug: string): boolean;
    setSession(params: {
        usuario: HubUser;
        accessToken: string;
        refreshToken: string;
        sessao: HubSessionInfo;
    }): void;
    setLoginResponse(response: HubLoginResponse): void;
    setRefreshResponse(response: HubRefreshResponse): void;
    setUsuario(usuario: HubUser): void;
    setAccessToken(accessToken: string): void;
    clearSession(): void;
    reloadFromStorage(): void;
    private loadUserFromStorage;
    private loadSessionFromStorage;
    updateModuleFavorite(slug: string, favorito: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HubSessionService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<HubSessionService>;
}

interface HubNavigationItem {
    rota: string;
    modulo_slug?: string;
    cor_icone?: string;
    icone?: string;
    children?: HubNavigationItem[];
}
declare class HubNavigationService {
    private readonly router;
    navigateRoute(route: string, item?: HubNavigationItem): void;
    private resolveRoute;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HubNavigationService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<HubNavigationService>;
}

declare const hubAuthInterceptor: HttpInterceptorFn;

declare const hubAuthGuard: CanActivateFn;

declare const hubPermissionGuard: CanActivateFn;

declare const HUB_ACCESS_TOKEN_KEY: InjectionToken<string>;
declare const HUB_REFRESH_TOKEN_KEY: InjectionToken<string>;
declare const HUB_USER_KEY: InjectionToken<string>;
declare const HUB_SESSION_KEY: InjectionToken<string>;

export { HUB_ACCESS_TOKEN_KEY, HUB_REFRESH_TOKEN_KEY, HUB_SESSION_KEY, HUB_USER_KEY, HubNavigationService, HubSessionService, hubAuthGuard, hubAuthInterceptor, hubPermissionGuard };
export type { HubAuthState, HubLoginResponse, HubModulo, HubNavigationItem, HubRefreshResponse, HubRemoteModule, HubSessionInfo, HubUser };
